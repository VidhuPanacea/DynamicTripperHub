export default function DetailedBlog() {
    return <></>
}